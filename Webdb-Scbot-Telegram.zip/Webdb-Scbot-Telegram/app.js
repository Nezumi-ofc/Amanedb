const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const session = require("express-session");
const fetch = require("node-fetch");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;
const ADMIN_PASSWORD = process.env.PW_ADMIN_LOGIN

// ✅ DAFTAR USER ID VALID (Contoh)
const VALID_USER_IDS = process.env.PW_USER_LOGIN

// 🔐 Variabel GitHub dari .env
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GITHUB_OWNER = process.env.GITHUB_OWNER;
const GITHUB_REPO = process.env.GITHUB_REPO;
const FILE_PATH = process.env.FILE_PATH;

// 🧩 Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(
  session({
    secret: "secret-token",
    resave: false,
    saveUninitialized: true,
  })
);
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// === Helper untuk GitHub JSON ===
async function loadTokens() {
  const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${FILE_PATH}`;
  const res = await fetch(url, {
    headers: { Authorization: `token ${GITHUB_TOKEN}` },
  });
  if (res.status !== 200) {
      console.error("Gagal memuat file dari GitHub:", res.statusText);
      return [];
  }
  const data = await res.json();
  if (!data.content) return [];
  const decoded = Buffer.from(data.content, "base64").toString("utf8");
  try {
      return JSON.parse(decoded);
  } catch (e) {
      console.error("Gagal parse JSON dari GitHub:", e);
      return [];
  }
}

async function saveTokens(tokens) {
  const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${FILE_PATH}`;
  const getRes = await fetch(url, {
    headers: { Authorization: `token ${GITHUB_TOKEN}` },
  });
  const getData = await getRes.json();
  const sha = getData.sha;

  const newContent = Buffer.from(JSON.stringify(tokens, null, 2)).toString("base64");

  const saveRes = await fetch(url, {
    method: "PUT",
    headers: {
      Authorization: `token ${GITHUB_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message: "Update tokens via dashboard",
      content: newContent,
      sha: sha,
    }),
  });
  
  if (saveRes.status !== 200 && saveRes.status !== 201) {
      const errorData = await saveRes.json();
      throw new Error(`Gagal menyimpan ke GitHub: ${saveRes.status} - ${errorData.message}`);
  }
}
// ------------------------------------

// Fungsi Helper untuk Render Dashboard Admin
async function renderAdminDashboard(req, res, result = null) {
  const tokens = await loadTokens();
  return res.render("admin_dashboard", {
      tokens,
      total: tokens.length,
      result: result
  });
}

// ------------------------------------
// ✅ ROUTE BARU UNTUK USER LOGIN
// ------------------------------------

app.get("/user/login", (req, res) => {
    // Jika user sudah login (userLoggedIn), arahkan ke halaman utama
    if (req.session.userLoggedIn) return res.redirect("/"); 
    res.render("user_login", { error: null });
});

app.post("/user/login", (req, res) => {
    const userId = req.body.userId; // Ambil field dari form user_login
    
    if (VALID_USER_IDS.includes(userId)) {
        req.session.userLoggedIn = true;
        req.session.userId = userId; // Simpan User ID di sesi
        
        // PENTING: Simpan sesi sebelum redirect
        req.session.save(err => {
            if (err) {
                console.error("Error saving user session:", err);
                return res.render("user_login", { error: "Gagal menyimpan sesi. Coba lagi." });
            }
            return res.redirect("/"); // Arahkan ke halaman utama
        });
        return;
    }
    
    res.render("user_login", { error: "Kode Akses tidak valid atau tidak terdaftar." });
});

// ------------------------------------
// ✅ MODIFIKASI ROUTE USER (Halaman Utama)
// ------------------------------------

// 🏠 Halaman user
app.get("/", (req, res) => {
  // ✅ Sekarang Halaman Utama Dilindungi
  if (!req.session.userLoggedIn) return res.redirect("/user/login");

  // Jika sudah login, lanjutkan render halaman index
  res.render("index", { result: null });
});


app.post("/add-token", async (req, res) => {
  const { token, redirect } = req.body;
  const isFromAdmin = redirect === '/dashboard';
  
  const renderer = isFromAdmin ? 
    (data) => renderAdminDashboard(req, res, data.result) : 
    (data) => res.render("index", data);
  
  if (isFromAdmin && !req.session.loggedIn) return res.redirect("/admin");
  
  if (!token) {
    return renderer({ result: { status: false, message: "Masukkan token!" } });
  }
  
  try {
    let tokens = await loadTokens();
    
    if (tokens.includes(token)) {
        return renderer({ result: { status: false, message: `Token sudah terdaftar!` } });
    }
    
    tokens.push(token);
    await saveTokens(tokens);
    
    return renderer({ result: { status: true, message: `Token berhasil ditambahkan!` } });

  } catch (error) {
    console.error("Error pada /add-token:", error.message);
    return renderer({ result: { status: false, message: `Gagal menambahkan token: ${error.message}` } });
  }
});

app.post("/check-token", async (req, res) => {
  const { token, redirect } = req.body;
  const isFromAdmin = redirect === '/dashboard';

  const renderer = isFromAdmin ? 
    (data) => renderAdminDashboard(req, res, data.result) : 
    (data) => res.render("index", data);
    
  if (isFromAdmin && !req.session.loggedIn) return res.redirect("/admin");
  
  if (!token) {
    return renderer({ result: { status: false, message: "Masukkan token untuk dicek!" } });
  }

  try {
    let tokens = await loadTokens();
    const exists = tokens.includes(token);
    
    return renderer({
      result: {
        status: exists ? true : false,
        message: exists ? 
                 `Token terdaftar dan aktif!` : 
                 `Token tidak ditemukan!`,
      }
    });
  } catch (error) {
      console.error("Error pada /check-token:", error.message);
      return renderer({ result: { status: false, message: `Gagal memeriksa token: ${error.message}` } 
    });
  }
});

// ⚙️ API tambahan info (tetap sama)
app.get("/set", (req, res) => {
  res.json({
    api_title: "Xskycode Token Dashboard",
    contact_whatsapp: process.env.CONTACT_OWNER || "https://t.me/Xskycode",
  });
});

app.get("/raw", async (req, res) => {
  const data = await loadTokens()
  res.json(data);
});

// ------------------------------------
// ✅ ROUTE ADMIN (Diperbaiki session.save)
// ------------------------------------

// 🧑‍💼 Halaman Login Admin
app.get("/admin", (req, res) => {
  if (req.session.loggedIn) return res.redirect("/dashboard");
  res.render("admin_login", { error: null });
});

app.post("/admin", (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    req.session.loggedIn = true;
    
    // PENTING: Simpan sesi sebelum redirect (untuk mengatasi ERR_TOO_MANY_REDIRECTS)
    req.session.save(err => {
        if (err) return res.render("admin_login", { error: "Gagal menyimpan sesi. Coba lagi." });
        return res.redirect("/dashboard");
    });
    return;
  }
  res.render("admin_login", { error: "Password salah!" });
});

// 🔐 Dashboard Admin
app.get("/dashboard", async (req, res) => {
  if (!req.session.loggedIn) return res.redirect("/admin");
  return renderAdminDashboard(req, res, null);
});

// 🗑️ Hapus Token
app.post("/delete-token", async (req, res) => {
  if (!req.session.loggedIn) return res.redirect("/admin");
  const { token } = req.body;
  
  let tokens = await loadTokens();
  
  if (tokens.includes(token)) {
      tokens = tokens.filter((t) => t !== token);
      await saveTokens(tokens);
      return renderAdminDashboard(req, res, { status: true, message: `Token ${token} berhasil dihapus.` });
  }
  
  return renderAdminDashboard(req, res, { status: false, message: `Gagal menghapus. Token ${token} tidak ditemukan.` });
});


// 🔁 Reset Semua Token
app.post("/reset-tokens", async (req, res) => {
  if (!req.session.loggedIn) return res.redirect("/admin");
  try {
      await saveTokens([]);
      return renderAdminDashboard(req, res, { status: true, message: "Semua token berhasil di-reset!" });
  } catch (error) {
      console.error("Error pada /reset-tokens:", error.message);
      return renderAdminDashboard(req, res, { status: false, message: `Gagal reset token: ${error.message}` });
  }
});

// 🚪 Logout
app.get("/logout", (req, res) => {
  // ✅ Hancurkan sesi admin
  if (req.session.loggedIn) {
      req.session.destroy();
      return res.redirect("/admin");
  }
  // ✅ Hancurkan sesi user (jika ada)
  if (req.session.userLoggedIn) {
      req.session.destroy();
      return res.redirect("/user/login");
  }
  res.redirect("/");
});

// 🚀 Jalankan server
app.listen(PORT, () => console.log(`Server berjalan di http://localhost:${PORT}`));
